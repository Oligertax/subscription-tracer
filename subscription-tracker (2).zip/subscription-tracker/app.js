/* =========================================================
   SubTrack — a small JavaScript library for the tracker.
   Public API:  SubTrack.Store, SubTrack.Validator,
                SubTrack.Status, SubTrack.UI, SubTrack.init()
   The page is wired up automatically on DOMContentLoaded.
   ========================================================= */
(function (global) {
  "use strict";

  var STORAGE_KEY = "subtrack.subscriptions.v1";
  var SOON_DAYS = 7;
  var FIELDS = ["service", "provider", "subscriber", "renewal", "category"];
  var LABELS = {
    service: "Service", provider: "Provider", subscriber: "Subscriber",
    renewal: "Renewal date", category: "Category"
  };

  /* ---------- Status ---------- */
  var Status = {
    startOfDay: function (d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()); },
    parse: function (iso) {
      var p = String(iso).split("-");
      return new Date(+p[0], +p[1] - 1, +p[2]);
    },
    of: function (iso) {
      var days = Math.round((this.parse(iso) - this.startOfDay(new Date())) / 86400000);
      if (days < 0) return "expired";
      if (days <= SOON_DAYS) return "soon";
      return "active";
    },
    label: function (key) {
      return { active: "Active", soon: "Expiring soon", expired: "Expired" }[key];
    }
  };

  /* ---------- Store (localStorage) ---------- */
  var Store = {
    all: function () {
      try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
      catch (e) { return []; }
    },
    save: function (list) {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); } catch (e) {}
    },
    add: function (item) {
      var list = this.all();
      item.id = String(Date.now()) + Math.random().toString(16).slice(2, 6);
      list.push(item);
      this.save(list);
      return item;
    },
    update: function (id, item) {
      var list = this.all().map(function (s) { return s.id === id ? Object.assign({}, s, item) : s; });
      this.save(list);
    },
    remove: function (id) {
      this.save(this.all().filter(function (s) { return s.id !== id; }));
    },
    find: function (id) {
      return this.all().filter(function (s) { return s.id === id; })[0];
    },
    summary: function () {
      var list = this.all();
      return {
        total: list.length,
        expired: list.filter(function (s) { return Status.of(s.renewal) === "expired"; }).length
      };
    }
  };

  /* ---------- Validator (every field is required) ---------- */
  var Validator = {
    check: function (values) {
      var errors = {};
      FIELDS.forEach(function (f) {
        if (!values[f] || !String(values[f]).trim()) errors[f] = LABELS[f] + " is required.";
      });
      return errors;
    }
  };

  /* ---------- UI ---------- */
  var UI = {
    $: function (id) { return document.getElementById(id); },

    escape: function (text) {
      var d = document.createElement("div");
      d.textContent = text;
      return d.innerHTML;
    },

    formatDate: function (iso) {
      return Status.parse(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
    },

    readForm: function () {
      var v = {};
      FIELDS.forEach(function (f) { v[f] = UI.$("f-" + f).value.trim(); });
      return v;
    },

    showErrors: function (errors) {
      FIELDS.forEach(function (f) {
        var input = UI.$("f-" + f);
        var slot = document.querySelector('[data-error-for="f-' + f + '"]');
        slot.textContent = errors[f] || "";
        input.classList.toggle("sui-input-invalid", !!errors[f]);
      });
    },

    resetForm: function () {
      UI.$("sub-form").reset();
      UI.$("f-id").value = "";
      UI.$("f-submit").textContent = "Add subscription";
      UI.$("f-cancel").hidden = true;
      UI.$("form-title").textContent = "Add a subscription";
      UI.showErrors({});
    },

    startEdit: function (id) {
      var s = Store.find(id);
      if (!s) return;
      UI.$("f-id").value = s.id;
      FIELDS.forEach(function (f) { UI.$("f-" + f).value = s[f]; });
      UI.$("f-submit").textContent = "Save changes";
      UI.$("f-cancel").hidden = false;
      UI.$("form-title").textContent = "Edit subscription";
      UI.$("sub-form").scrollIntoView({ behavior: "smooth", block: "start" });
      UI.$("f-service").focus();
    },

    renderSummary: function () {
      var s = Store.summary();
      UI.$("stat-total").textContent = s.total;
      UI.$("stat-expired").textContent = s.expired;
    },

    renderTable: function () {
      var list = Store.all().sort(function (a, b) { return a.renewal.localeCompare(b.renewal); });
      var body = UI.$("sub-rows");
      body.innerHTML = list.map(function (s) {
        var st = Status.of(s.renewal);
        return '<tr class="' + (st === "expired" ? "sui-row-expired" : "") + '">' +
          "<td>" + UI.escape(s.service) + "</td>" +
          "<td>" + UI.escape(s.provider) + "</td>" +
          "<td>" + UI.escape(s.subscriber) + "</td>" +
          "<td>" + UI.formatDate(s.renewal) + "</td>" +
          "<td>" + UI.escape(s.category) + "</td>" +
          '<td><span class="sui-badge sui-badge-' + st + '">' + Status.label(st) + "</span></td>" +
          '<td><div class="sui-btn-group">' +
            '<button class="sui-btn sui-btn-ghost sui-btn-small" data-action="edit" data-id="' + s.id + '">Edit</button>' +
            '<button class="sui-btn sui-btn-danger sui-btn-small" data-action="delete" data-id="' + s.id + '">Delete</button>' +
          "</div></td></tr>";
      }).join("");
      UI.$("sub-empty").hidden = list.length > 0;
    },

    render: function () { UI.renderSummary(); UI.renderTable(); }
  };

  /* ---------- Init: wire the page ---------- */
  function init() {
    UI.$("sub-form").addEventListener("submit", function (e) {
      e.preventDefault();
      var values = UI.readForm();
      var errors = Validator.check(values);
      UI.showErrors(errors);
      if (Object.keys(errors).length) return;

      var id = UI.$("f-id").value;
      if (id) Store.update(id, values); else Store.add(values);
      UI.resetForm();
      UI.render();
    });

    UI.$("f-cancel").addEventListener("click", UI.resetForm);

    UI.$("sub-rows").addEventListener("click", function (e) {
      var btn = e.target.closest("button[data-action]");
      if (!btn) return;
      var id = btn.getAttribute("data-id");
      if (btn.getAttribute("data-action") === "edit") {
        UI.startEdit(id);
      } else if (window.confirm("Delete this subscription?")) {
        Store.remove(id);
        if (UI.$("f-id").value === id) UI.resetForm();
        UI.render();
      }
    });

    UI.render();
  }

  global.SubTrack = { Store: Store, Validator: Validator, Status: Status, UI: UI, init: init };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})(window);
